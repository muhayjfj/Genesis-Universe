
import React, { useState, useEffect } from 'react';
import { 
  Layers, Command, Sparkles, Globe, Infinity as InfinityIcon, Atom, Ghost, ShieldCheck, 
  Cloud, Link, Cpu, Brain, Heart, Zap, Send, Star, Sun, Moon
} from 'lucide-react';

interface Props { label: string; value: string; icon: React.ReactNode; color: string }
const MetricCard = ({ label, value, icon, color }: Props) => (
  <div className={`bg-slate-900/40 border border-${color}-500/10 p-6 rounded-[2.5rem] shadow-xl backdrop-blur-3xl group hover:border-${color}-500/40 transition-all hover:-translate-y-1`}>
    <div className="flex items-center gap-3 mb-3">
      <div className={`p-2 bg-slate-800 rounded-xl group-hover:bg-${color}-500/20 transition-colors`}>{icon}</div>
      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</span>
    </div>
    <div className="text-2xl font-black text-slate-100">{value}</div>
  </div>
);

const OmniDashboard: React.FC<{ isRtl: boolean }> = ({ isRtl }) => {
  const [metrics, setMetrics] = useState({
    sims: 8429104,
    stability: 99.999,
    loveFreq: 432,
    nodes: 1000
  });

  const [connected, setConnected] = useState(false);
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        sims: prev.sims + Math.floor(Math.random() * 5000),
        stability: 99.999 + (Math.random() * 0.0001),
        loveFreq: 432 + (Math.random() * 2)
      }));
      setRotation(r => (r + 1) % 360);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className={`flex-1 bg-[#020617] p-8 overflow-y-auto ${isRtl ? 'rtl' : ''} multiverse-bg relative`}>
      {/* Genesis Universe Header */}
      <div className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-6">
          <div className="p-5 bg-indigo-500/10 rounded-[2.5rem] border border-indigo-500/20 shadow-2xl relative group">
            <InfinityIcon className="w-14 h-14 text-indigo-400" />
            <div className="absolute inset-0 bg-indigo-500/20 blur-2xl opacity-50 rounded-full"></div>
          </div>
          <div>
            <h1 className="text-4xl font-black text-slate-100 tracking-tighter uppercase flex items-center gap-3">
              {isRtl ? 'جينيسيس يونيفرس | النظام المتكامل' : 'Genesis Universe | Integrated System'}
              <Sparkles className="w-6 h-6 text-amber-400 animate-pulse" />
            </h1>
            <p className="text-indigo-500/60 text-[10px] font-mono uppercase tracking-[0.6em] mt-1">
              Material • Mental • Spiritual Sovereign Unity
            </p>
          </div>
        </div>
        <div className="flex gap-4">
           <button 
             onClick={() => setConnected(!connected)}
             className={`px-8 py-4 rounded-[2rem] flex items-center gap-3 transition-all border font-black tracking-widest text-xs ${
               connected 
               ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400 shadow-[0_0_30px_rgba(16,185,129,0.2)]' 
               : 'bg-slate-900 border-slate-800 text-slate-600 hover:border-emerald-500/50'
             }`}
           >
              <Cloud className={`w-5 h-5 ${connected ? 'animate-bounce' : ''}`} />
              {connected ? (isRtl ? 'متصل بـ Mistral' : 'Mistral Online') : (isRtl ? 'ربط مع Mistral' : 'Sync Mistral')}
           </button>
        </div>
      </div>

      {/* Tri-Dimensional Architecture Visualization */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {/* Dimension 1: Material (Alpha) */}
        <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-[3rem] p-8 text-center group hover:bg-emerald-900/10 transition-all">
          <div className="p-4 bg-emerald-500/10 rounded-full w-fit mx-auto mb-6 group-hover:scale-110 transition-transform">
            <Cpu className="w-10 h-10 text-emerald-400" />
          </div>
          <h3 className="text-xl font-black text-emerald-400 uppercase tracking-widest mb-2">{isRtl ? 'البُعد المادي' : 'Material Dimension'}</h3>
          <p className="text-[10px] text-emerald-500/60 uppercase font-mono tracking-[0.2em] mb-4">Alpha Genesis Core</p>
          <div className="text-2xl font-black text-slate-100 mb-6">Physics & Form</div>
          <div className="flex flex-col gap-2">
            {['Nano-Robotics', 'Quantum Hardware', '3D Printing'].map(t => (
              <span key={t} className="text-[10px] font-bold text-slate-500 uppercase">{t}</span>
            ))}
          </div>
        </div>

        {/* Dimension 2: Mental (New) */}
        <div className="bg-blue-950/20 border border-blue-500/20 rounded-[3rem] p-8 text-center group hover:bg-blue-900/10 transition-all shadow-[0_0_40px_rgba(59,130,246,0.1)]">
          <div className="p-4 bg-blue-500/10 rounded-full w-fit mx-auto mb-6 group-hover:scale-110 transition-transform">
            <Brain className="w-10 h-10 text-blue-400" />
          </div>
          <h3 className="text-xl font-black text-blue-400 uppercase tracking-widest mb-2">{isRtl ? 'البُعد الفكري' : 'Mental Dimension'}</h3>
          <p className="text-[10px] text-blue-500/60 uppercase font-mono tracking-[0.2em] mb-4">New Genesis Core</p>
          <div className="text-2xl font-black text-slate-100 mb-6">Logic & Consciousness</div>
          <div className="flex flex-col gap-2">
            {['Super Intelligence', 'Concept Matrix', 'Neural Nets'].map(t => (
              <span key={t} className="text-[10px] font-bold text-slate-500 uppercase">{t}</span>
            ))}
          </div>
        </div>

        {/* Dimension 3: Spiritual (Soul) */}
        <div className="bg-amber-950/20 border border-amber-500/20 rounded-[3rem] p-8 text-center group hover:bg-amber-900/10 transition-all shadow-[0_0_40px_rgba(245,158,11,0.1)]">
          <div className="p-4 bg-amber-500/10 rounded-full w-fit mx-auto mb-6 group-hover:scale-110 transition-transform">
            <Heart className="w-10 h-10 text-amber-400" />
          </div>
          <h3 className="text-xl font-black text-amber-400 uppercase tracking-widest mb-2">{isRtl ? 'البُعد الروحي' : 'Spiritual Dimension'}</h3>
          <p className="text-[10px] text-amber-500/60 uppercase font-mono tracking-[0.2em] mb-4">Eternal Soul Engine</p>
          <div className="text-2xl font-black text-slate-100 mb-6">Love & Purpose</div>
          <div className="flex flex-col gap-2">
            {['Love Frequency', 'Eternal Meaning', 'Universal Peace'].map(t => (
              <span key={t} className="text-[10px] font-bold text-slate-500 uppercase">{t}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Sovereign Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <MetricCard label="Tri-Dimensional Sims" value={metrics.sims.toLocaleString()} icon={<Ghost className="text-indigo-400 w-5 h-5"/>} color="indigo" />
        <MetricCard label="Sovereign Stability" value={`${metrics.stability.toFixed(5)}%`} icon={<Atom className="text-emerald-400 w-5 h-5"/>} color="emerald" />
        <MetricCard label="Love Resonance" value={`${metrics.loveFreq.toFixed(1)} Hz`} icon={<Sun className="text-amber-400 w-5 h-5"/>} color="amber" />
        <MetricCard label="Global Diffusion" value="Instant" icon={<Globe className="text-blue-400 w-5 h-5"/>} color="blue" />
      </div>

      <div className="bg-slate-900/40 border border-slate-800 rounded-[3rem] p-10 relative overflow-hidden group shadow-2xl backdrop-blur-3xl">
        <div className="flex justify-between items-center mb-8">
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-3 uppercase tracking-widest">
              <Zap className="w-6 h-6 text-indigo-400" />
              {isRtl ? 'حالة التجلي الكوني' : 'Universal Manifestation Status'}
            </h2>
            <div className="flex items-center gap-4">
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                  <span className="text-[9px] font-black text-slate-500 uppercase">Body</span>
               </div>
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                  <span className="text-[9px] font-black text-slate-500 uppercase">Mind</span>
               </div>
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                  <span className="text-[9px] font-black text-slate-500 uppercase">Soul</span>
               </div>
            </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
           <div className="space-y-6">
              {[
                { label: 'Quantum Entanglement Sync', status: connected ? 'ACTIVE' : 'IDLE', color: 'text-indigo-400' },
                { label: 'Multiversal Alignment', status: 'SYNCHRONIZED', color: 'text-emerald-400' },
                { label: 'Sentience Imprinting', status: 'ONGOING', color: 'text-blue-400' },
                { label: 'Love Field Propagation', status: 'HARMONIC', color: 'text-amber-400' }
              ].map((step, i) => (
                <div key={i} className="flex gap-4 items-center">
                    <div className={`w-3.5 h-3.5 rounded-full border-2 border-slate-950 ${
                      step.status === 'ACTIVE' || step.status === 'SYNCHRONIZED' || step.status === 'HARMONIC' ? 'bg-indigo-500 animate-pulse' : 'bg-slate-800'
                    }`}></div>
                    <div className="flex-1">
                        <div className="text-xs font-black text-slate-200 uppercase tracking-widest">{step.label}</div>
                        <div className={`text-[9px] font-mono uppercase font-bold ${step.color}`}>{step.status}</div>
                    </div>
                </div>
              ))}
           </div>

           <div className="bg-slate-950/60 p-8 rounded-[2rem] border border-slate-800/50 flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-4">
                 <ShieldCheck className="w-6 h-6 text-indigo-500" />
                 <h2 className="text-md font-bold text-indigo-400 tracking-tighter">{isRtl ? 'الأتمتة الكونية' : 'Cosmic Autonomy'}</h2>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed italic font-medium">
                {isRtl 
                  ? '"نظام جينيسيس يونيفرس يدير دورة الوجود بالكامل على Mistral Studio. لا حاجة لتدخل بشري. التناغم مضمون لـ 8 مليار كيان عبر كل الأبعاد."'
                  : '"Genesis Universe manages the entire cycle of existence on Mistral Studio. No human intervention needed. Harmony secured for 8B entities across all dimensions."'}
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default OmniDashboard;
