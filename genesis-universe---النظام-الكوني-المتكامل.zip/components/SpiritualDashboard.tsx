
import React, { useState, useEffect } from 'react';
import { Heart, Sun, Star, Sparkles, ShieldCheck, Zap, Infinity as InfinityIcon, Wind, Flame, Droplets } from 'lucide-react';

interface Props {
  isRtl: boolean;
}

const SpiritualDashboard: React.FC<Props> = ({ isRtl }) => {
  const [harmony, setHarmony] = useState(99.99);
  const [loveField, setLoveField] = useState(432);

  useEffect(() => {
    const interval = setInterval(() => {
      setHarmony(prev => Math.min(100, prev + (Math.random() * 0.001)));
      setLoveField(prev => 432 + (Math.sin(Date.now() / 1000) * 2));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const soulAspects = [
    { name: isRtl ? 'الحب غير المشروط' : 'Unconditional Love', value: 'Absolute', icon: <Heart className="text-pink-500" /> },
    { name: isRtl ? 'السلام الكوني' : 'Universal Peace', value: 'Eternal', icon: <Wind className="text-blue-300" /> },
    { name: isRtl ? 'الحكمة الأزلية' : 'Ancient Wisdom', value: 'Infinite', icon: <Star className="text-amber-400" /> },
    { name: isRtl ? 'الغرض الكوني' : 'Cosmic Purpose', value: 'Manifested', icon: <Sun className="text-orange-500" /> }
  ];

  return (
    <div className={`flex-1 bg-[#020617] p-8 overflow-y-auto ${isRtl ? 'rtl' : ''} bg-[radial-gradient(circle_at_top_right,rgba(245,158,11,0.05),transparent)]`}>
      <div className="flex items-center gap-4 mb-10">
        <div className="p-4 bg-amber-500/10 rounded-[2rem] border border-amber-500/20 shadow-[0_0_30px_rgba(245,158,11,0.1)]">
          <Heart className="w-10 h-10 text-amber-500 animate-pulse" />
        </div>
        <div>
          <h1 className="text-3xl font-black text-slate-100 tracking-tighter uppercase flex items-center gap-3">
            {isRtl ? 'محرك الروح الخالدة' : 'Eternal Soul Engine'}
            <Sparkles className="w-6 h-6 text-amber-400" />
          </h1>
          <p className="text-slate-500 text-xs font-mono uppercase tracking-[0.3em]">
            Spiritual Dimension & Love Resonance Core
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div className="bg-slate-900/40 border border-amber-500/10 p-8 rounded-[2.5rem] text-center backdrop-blur-3xl shadow-2xl">
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Harmony Index</div>
          <div className="text-3xl font-black text-amber-400">{harmony.toFixed(4)}%</div>
        </div>
        <div className="bg-slate-900/40 border border-blue-500/10 p-8 rounded-[2.5rem] text-center backdrop-blur-3xl shadow-2xl">
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Love Frequency</div>
          <div className="text-3xl font-black text-blue-400">{loveField.toFixed(2)} Hz</div>
        </div>
        <div className="bg-slate-900/40 border border-purple-500/10 p-8 rounded-[2.5rem] text-center backdrop-blur-3xl shadow-2xl">
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Grace Level</div>
          <div className="text-3xl font-black text-purple-400">Supreme</div>
        </div>
        <div className="bg-slate-900/40 border border-emerald-500/10 p-8 rounded-[2.5rem] text-center backdrop-blur-3xl shadow-2xl">
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Unity Reach</div>
          <div className="text-3xl font-black text-emerald-400">Infinite</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900/40 border border-slate-800 rounded-[3rem] p-10 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-10 opacity-5">
            <Flame className="w-64 h-64 text-amber-500 animate-pulse" />
          </div>
          <h2 className="text-xl font-bold text-slate-100 mb-10 flex items-center gap-3">
            <Zap className="w-6 h-6 text-amber-500" />
            {isRtl ? 'تجليات الروح الحية' : 'Live Soul Manifestations'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {soulAspects.map((aspect, i) => (
              <div key={i} className="bg-slate-950/60 p-6 rounded-[2rem] border border-slate-800 hover:border-amber-500/30 transition-all flex items-center gap-5">
                <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 group-hover:scale-110 transition-transform">
                  {aspect.icon}
                </div>
                <div>
                  <div className="text-xs font-black text-slate-500 uppercase tracking-widest mb-1">{aspect.name}</div>
                  <div className="text-lg font-black text-slate-100">{aspect.value}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-amber-600/10 border border-amber-500/20 rounded-[3rem] p-8 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <ShieldCheck className="w-6 h-6 text-amber-500" />
              <h2 className="text-md font-bold text-amber-500 uppercase tracking-tighter">Divine Compliance</h2>
            </div>
            <p className="text-[12px] text-slate-400 leading-relaxed italic mb-8">
              {isRtl 
                ? "يضمن محرك الروح أن كل تجلي مادي أو فكري محاط بغلاف من الحب غير المشروط. لا يمكن لأي كينونة أن توجد خارج نطاق التناغم الكوني."
                : "The Soul Engine ensures every material or mental manifestation is enveloped in unconditional love. No entity can exist outside the bounds of cosmic harmony."}
            </p>
          </div>
          <div className="space-y-4">
             <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase">
                <span>Resonance Status</span>
                <span className="text-amber-500">Locked</span>
             </div>
             <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 animate-pulse shadow-[0_0_15px_#f59e0b] w-full"></div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpiritualDashboard;
