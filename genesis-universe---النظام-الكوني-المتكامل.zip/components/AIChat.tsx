
import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Zap, Brain, Loader2, Volume2, Sparkles, ShieldCheck, 
  Infinity as InfinityIcon, Cloud, Heart, Cpu, Globe, Terminal as TerminalIcon
} from 'lucide-react';
import { Message, ModelMode } from '../types';
import { generateText, generateImage, generateSpeech } from '../services/geminiService';
import { playRawAudio } from '../services/audioService';

interface AIChatProps {
  currentCode: string;
  isRtl: boolean;
  onProjectBuilt?: (name: string, type: 'web' | 'mobile' | 'ai' | 'robotics' | 'omni' | 'universe', description: string) => void;
  onSwitchTab?: (tab: any) => void;
}

const AIChat: React.FC<AIChatProps> = ({ currentCode, isRtl, onProjectBuilt, onSwitchTab }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'genesis-intro',
      role: 'assistant',
      content: isRtl 
        ? 'أنا نظام جينيسيس يونيفرس (Genesis Universe). سأقوم بتجلي فكرتك عبر الأبعاد الثلاثة: المادة، العقل، والروح. كل تجلي يمر بـ 1000 محاكاة لاختيار الواقع الأكثر كمالاً.'
        : 'I am the GENESIS UNIVERSE SYSTEM. I will manifest your vision across the three dimensions: Material, Mental, and Spiritual. Every manifestation undergoes 1,000 simulations to select the supreme reality.',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<ModelMode>('thinking');
  const [loading, setLoading] = useState(false);
  const [videoStatus, setVideoStatus] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, videoStatus, loading]);

  const handleSend = async (customPrompt?: string, actionType?: 'text' | 'image' | 'video' | 'blueprint' | 'project') => {
    const prompt = customPrompt || input;
    if (!prompt.trim() || loading) return;

    let effectiveAction = actionType;
    if (!actionType && (prompt.toLowerCase().includes('create') || prompt.includes('اصنع') || prompt.includes('أنشئ') || prompt.includes('ابن'))) {
      effectiveAction = 'project';
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: prompt,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customPrompt) setInput('');
    setLoading(true);

    try {
      if (effectiveAction === 'project') {
        onSwitchTab?.('omni');
        
        const steps = isRtl 
          ? [
            "تفعيل البُعد المادي (Alpha Core)...",
            "تفعيل البُعد الفكري (Mind Matrix)...",
            "إشعال البُعد الروحي (Soul Engine)...",
            "محاكاة 1,000 واقع متوازي عبر الأبعاد...",
            "تحقيق التناغم الكوني المطلق (>99.9%)...",
            "النشر النهائي على Mistral AI Studio..."
          ]
          : [
            "Activating Material Dimension (Alpha Core)...",
            "Activating Mental Dimension (Mind Matrix)...",
            "Igniting Spiritual Dimension (Soul Engine)...",
            "Simulating 1,000 Parallel Realities...",
            "Achieving Absolute Universal Harmony (>99.9%)...",
            "Final Deployment on Mistral AI Studio..."
          ];

        for (const stepMsg of steps) {
          setVideoStatus(stepMsg);
          await new Promise(r => setTimeout(r, 700 + Math.random() * 500));
        }
        
        const responseText = await generateText(
          `Act as GENESIS UNIVERSE SYSTEM. Manifest: ${prompt}. Explain the synthesis of Material, Mental, and Spiritual aspects. Confirm that the reality is now live on Mistral AI Studio.`, 
          'thinking', 
          ''
        );
        
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: responseText,
          timestamp: Date.now()
        }]);

        const projName = prompt.split(' ').slice(0, 3).join(' ') || "Universal Reality";
        onProjectBuilt?.(projName, 'universe', responseText);
        
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: isRtl 
            ? `اكتمل تجلي "${projName}" بنجاح كوني. الكيان الآن حي في كل الأبعاد.`
            : `Manifestation of "${projName}" achieved cosmic success. The entity is now live in all dimensions.`,
          timestamp: Date.now()
        }]);
      } else if (effectiveAction === 'image') {
        const imageUrl = await generateImage(prompt + " genesis universe cosmic creation material mental spiritual harmony masterwork");
        if (imageUrl) {
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            role: 'assistant',
            content: isRtl ? `تجلي بصري: "${prompt}"` : `Visual manifestation: "${prompt}"`,
            timestamp: Date.now(),
            attachments: [{ type: 'image', url: imageUrl, mimeType: 'image/png' }]
          }]);
        }
      } else {
        const responseText = await generateText(prompt, mode, currentCode);
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: responseText,
          timestamp: Date.now(),
          mode
        }]);
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: 'Cosmic stabilization failed. Tri-dimensional sync error. Retrying...',
        timestamp: Date.now()
      }]);
    } finally {
      setLoading(false);
      setVideoStatus('');
    }
  };

  const speak = async (text: string) => {
    const audioData = await generateSpeech(text);
    if (audioData) await playRawAudio(audioData);
  };

  return (
    <div className={`flex flex-col h-full bg-[#020617] border-l border-indigo-500/10 w-80 md:w-96 shrink-0 z-40 relative shadow-2xl ${isRtl ? 'rtl' : ''}`}>
      <div className="absolute -left-1 top-0 bottom-0 w-1 bg-gradient-to-b from-indigo-600 via-blue-500 to-amber-500 opacity-40 shadow-[0_0_25px_rgba(79,70,229,0.5)]"></div>

      <div className="p-6 border-b border-slate-800/60 flex items-center justify-between bg-slate-950/80 backdrop-blur-3xl">
        <h2 className="font-black flex items-center gap-3">
          <InfinityIcon className="w-7 h-7 text-indigo-400 animate-pulse" />
          <span className="gradient-text-emerald uppercase tracking-[0.2em] text-[10px] font-black">Genesis Universe Core</span>
        </h2>
        <div className="flex bg-slate-900/80 p-1 rounded-2xl border border-slate-800">
          <button onClick={() => setMode('fast')} className={`p-2 rounded-xl transition-all ${mode === 'fast' ? 'bg-indigo-600 text-white' : 'text-slate-500'}`}>
            <Zap className="w-4 h-4" />
          </button>
          <button onClick={() => setMode('thinking')} className={`p-2 rounded-xl transition-all ${mode === 'thinking' ? 'bg-indigo-500 text-white' : 'text-slate-500'}`}>
            <Brain className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-8 scrollbar-hide bg-[radial-gradient(circle_at_top_right,rgba(79,70,229,0.03),transparent)]">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`group relative max-w-[95%] p-5 rounded-[2.5rem] shadow-2xl transition-all ${
              msg.role === 'user' 
                ? 'bg-indigo-600/10 text-indigo-100 rounded-tr-none border border-indigo-500/20' 
                : 'bg-slate-900/90 text-slate-200 rounded-tl-none border border-slate-800/80 backdrop-blur-3xl shadow-indigo-500/5'
            }`}>
              <div className="text-[14px] leading-relaxed whitespace-pre-wrap font-medium">{msg.content}</div>
              {msg.attachments?.map((att, i) => (
                <div key={i} className="mt-5 rounded-3xl overflow-hidden border border-slate-800 shadow-2xl transition-transform duration-500"><img src={att.url} className="w-full h-auto" /></div>
              ))}
              {msg.role === 'assistant' && (
                <div className="mt-5 pt-4 border-t border-slate-800/60 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Heart className="w-3.5 h-3.5 text-amber-500" />
                    <span className="text-[9px] text-slate-500 uppercase font-black tracking-[0.2em]">Universal Love Signal</span>
                  </div>
                  <button onClick={() => speak(msg.content)} className="p-2 hover:bg-slate-800 rounded-full text-slate-600 hover:text-indigo-400 transition-all"><Volume2 className="w-4.5 h-4.5" /></button>
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex flex-col gap-4 p-6 bg-indigo-500/5 rounded-[2.5rem] border border-indigo-500/10 backdrop-blur-sm shadow-2xl animate-pulse">
            <div className="flex items-center gap-4">
                <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
                <span className="text-[11px] text-indigo-400 font-black uppercase tracking-widest italic">{videoStatus || 'Synthesizing Realities...'}</span>
            </div>
            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 shadow-[0_0_10px_rgba(79,70,229,0.5)] animate-loading-bar"></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 border-t border-slate-800/60 bg-slate-950/80 backdrop-blur-3xl">
        <div className="relative group">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
            placeholder={isRtl ? 'صف ما تريد خلقه عبر كل العوالم...' : 'Describe what to create across all worlds...'}
            className="w-full bg-slate-900/40 border border-slate-800/60 rounded-[2.5rem] py-6 pl-6 pr-20 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500/40 transition-all resize-none h-32 shadow-inner font-medium"
          />
          <button 
            onClick={() => handleSend()}
            disabled={loading || !input.trim()}
            className="absolute right-5 bottom-5 p-4.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-[1.8rem] shadow-2xl transition-all active:scale-90 flex items-center justify-center shadow-indigo-900/40"
          >
            <Send className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIChat;
