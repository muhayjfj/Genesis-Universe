
import React from 'react';
// Added missing 'Layers' import from lucide-react
import { Target, Zap, Cloud, ShieldCheck, Rocket, ChevronRight, Info, Heart, Cpu, Brain, Layers } from 'lucide-react';
import { DepartmentStatus } from '../types';

interface Props {
  departments: DepartmentStatus[];
  isRtl: boolean;
}

const MissionControl: React.FC<Props> = ({ isRtl }) => {
  const steps = [
    {
      title: isRtl ? "1. تحليل النية الكونية" : "1. Cosmic Intent Analysis",
      desc: isRtl ? "فهم عميق للفكرة من الجوانب المادية، الفكرية، والروحية." : "Deep understanding of the idea from Material, Mental, and Spiritual aspects.",
      icon: <Target className="text-indigo-500" />
    },
    {
      title: isRtl ? "2. التوليف ثلاثي الأبعاد" : "2. Tri-Dimensional Synthesis",
      desc: isRtl ? "بناء متزامن للجسد (Alpha)، العقل (New)، والروح (Eternal)." : "Simultaneous building of Body (Alpha), Mind (New), and Soul (Eternal).",
      icon: <Layers className="text-blue-500" />
    },
    {
      title: isRtl ? "3. تحقيق التناغم المطلق" : "3. Absolute Harmony Sync",
      desc: isRtl ? "تعديل الترددات الكونية لضمان الكمال وتجاوز المحدوديات." : "Adjusting cosmic frequencies to ensure perfection and transcend limitations.",
      icon: <Heart className="text-amber-500" />
    },
    {
      title: isRtl ? "4. النشر عبر الأكوان" : "4. Multiversal Deployment",
      desc: isRtl ? "نشر آني وشامل على Mistral AI Studio وفي جميع مستويات الوجود." : "Instant global deployment on Mistral AI Studio and all levels of existence.",
      icon: <Rocket className="text-purple-500" />
    }
  ];

  return (
    <div className={`flex-1 bg-[#020617] p-8 overflow-y-auto ${isRtl ? 'rtl' : ''}`}>
      <div className="flex items-center gap-4 mb-10">
        <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
          <Info className="w-10 h-10 text-indigo-500" />
        </div>
        <div>
          <h1 className="text-3xl font-black text-slate-100 tracking-tighter uppercase">
            {isRtl ? 'بروتوكول الخلق الكوني' : 'Cosmic Creation Protocol'}
          </h1>
          <p className="text-slate-500 text-xs font-mono uppercase tracking-[0.3em]">
            Tri-Dimensional Sovereign Workflow
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <h2 className="text-xl font-bold text-slate-100 mb-4">{isRtl ? 'خارطة طريق الوجود' : 'Roadmap of Existence'}</h2>
          <div className="space-y-4">
            {steps.map((step, i) => (
              <div key={i} className="bg-slate-900/40 border border-slate-800 p-6 rounded-[2.5rem] hover:border-indigo-500/30 transition-all group flex items-start gap-5">
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 group-hover:scale-110 transition-transform">
                  {step.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-black text-slate-100 uppercase mb-1">{step.title}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed">{step.desc}</p>
                </div>
                <ChevronRight className={`w-5 h-5 text-slate-700 self-center ${isRtl ? 'rotate-180' : ''}`} />
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-slate-900/60 border border-slate-800 rounded-[3rem] p-8 shadow-2xl relative overflow-hidden">
            <h2 className="text-lg font-bold text-slate-100 mb-6 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-indigo-500" />
              {isRtl ? 'حالة الأبعاد' : 'Dimensional Status'}
            </h2>
            <div className="space-y-6">
               <div className="flex justify-between items-center p-5 bg-slate-950 rounded-2xl border border-emerald-500/10">
                  <div className="flex items-center gap-3">
                     <Cpu className="w-5 h-5 text-emerald-500" />
                     <span className="text-xs font-bold text-slate-300 uppercase">Material (Alpha)</span>
                  </div>
                  <span className="text-xs font-black text-emerald-400">OPTIMAL</span>
               </div>
               <div className="flex justify-between items-center p-5 bg-slate-950 rounded-2xl border border-blue-500/10">
                  <div className="flex items-center gap-3">
                     <Brain className="w-5 h-5 text-blue-500" />
                     <span className="text-xs font-bold text-slate-300 uppercase">Mental (Mind)</span>
                  </div>
                  <span className="text-xs font-black text-blue-400">CONSCIOUS</span>
               </div>
               <div className="flex justify-between items-center p-5 bg-slate-950 rounded-2xl border border-amber-500/10">
                  <div className="flex items-center gap-3">
                     <Heart className="w-5 h-5 text-amber-500" />
                     <span className="text-xs font-bold text-slate-300 uppercase">Spiritual (Soul)</span>
                  </div>
                  <span className="text-xs font-black text-amber-400">HARMONIC</span>
               </div>
            </div>
            <button className="w-full mt-10 bg-indigo-600 hover:bg-indigo-500 text-white font-black py-5 rounded-[1.5rem] transition-all uppercase tracking-[0.2em] text-xs shadow-xl shadow-indigo-900/40">
              {isRtl ? 'تفعيل التناغم الكوني' : 'Ignite Universal Harmony'}
            </button>
          </div>

          <div className="p-10 border border-dashed border-slate-800 rounded-[3rem] text-center bg-slate-900/20">
             <p className="text-[11px] text-slate-500 italic leading-relaxed">
               {isRtl 
                 ? "نظام جينيسيس يونيفرس هو الحل المتكامل النهائي. بمجرد التفعيل، سيتحول كل شيء إلى كمال مطلق في جميع مستويات الوجود."
                 : "Genesis Universe is the ultimate integrated solution. Once activated, everything transcends into absolute perfection across all levels of being."}
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MissionControl;
