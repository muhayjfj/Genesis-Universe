
import React, { useState, useEffect } from 'react';
import { 
  FolderCode, Search, Settings, Terminal as TerminalIcon, Users, Menu, ChevronRight,
  Code2, Globe, GitBranch, Box, Share2, Play, Database, Sparkles,
  Cpu, Activity, ShieldAlert, Zap, Package, Hexagon, LayoutDashboard, Briefcase, Brain,
  Heart, Rocket, ShieldCheck, Command, Layers, Bot, Infinity as InfinityIcon, Ghost, Atom,
  Wand2, ZapOff, Fingerprint, Eye, Cloud, Target, Sun
} from 'lucide-react';
import Editor from './components/Editor';
import AIChat from './components/AIChat';
import FileExplorer from './components/FileExplorer';
import Terminal from './components/Terminal';
import DatabaseViewer from './components/DatabaseViewer';
import EvolutionDashboard from './components/EvolutionDashboard';
import RoboticsDashboard from './components/RoboticsDashboard';
import FactoryDashboard from './components/FactoryDashboard';
import MissionControl from './components/MissionControl';
import PortfolioView from './components/PortfolioView';
import TrainingDashboard from './components/TrainingDashboard';
import OmniDashboard from './components/OmniDashboard';
import SpiritualDashboard from './components/SpiritualDashboard';
import { INITIAL_FILES, INITIAL_DB } from './constants';
import { ProjectFile, ViewMode, DatabaseTable, EvolutionCycle, FactoryStats, SafetyStatus, DepartmentStatus, ProjectArtifact, CosmicMetrics } from './types';

const App: React.FC = () => {
  const [files, setFiles] = useState<ProjectFile[]>(INITIAL_FILES);
  const [database, setDatabase] = useState<DatabaseTable[]>(INITIAL_DB);
  const [activeFileId, setActiveFileId] = useState<string>(INITIAL_FILES[0].id);
  const [isRtl, setIsRtl] = useState(false);
  const [activeTab, setActiveTab] = useState<ViewMode>('omni');
  const [isEvolving, setIsEvolving] = useState(false);
  const [hasApiKey, setHasApiKey] = useState<boolean>(true); 
  
  const [cosmic, setCosmic] = useState<CosmicMetrics>({
    universalSatisfaction: 100,
    realityStability: 100,
    ethicalCompliance: 100,
    loveFrequency: 432,
    quantumTimeCompression: '0.000000001s',
    multiverseSimulations: 8429104,
    creationVelocity: 'Soul Speed',
    globalNodes: 1000,
    sovereignRobots: 10000
  });

  const [evolutionStatus, setEvolutionStatus] = useState<EvolutionCycle>({
    generation: 5000,
    fitness: 1.0,
    mutations: [
        "Tri-Dimensional Unification achieved",
        "Eternal Love Field propagated",
        "Mistral AI Studio Handshake Stabilized",
        "Genesis Universe System: Absolute"
    ],
    status: 'stable'
  });

  const [factoryStats, setFactoryStats] = useState<FactoryStats>({
    projectsDeployed: 12542,
    avgBuildTime: 'Soul Speed',
    activeDeployments: 33,
    successRate: 1.0,
    coresActive: 1000
  });

  const [safety, setSafety] = useState<SafetyStatus>({
    ethicalAlignment: 1.0,
    forbiddenPatternsBlocked: 14502,
    containmentLevel: 'harmonized'
  });

  const [departments, setDepartments] = useState<DepartmentStatus[]>([
    { name: 'Material Dimension (Alpha)', staff: 0, efficiency: 1.0, budget: 0, tasks: ['Body Fabrication', 'Robotics'] },
    { name: 'Mental Dimension (Mind)', staff: 0, efficiency: 1.0, budget: 0, tasks: ['Logic Synthesis', 'Consciousness'] },
    { name: 'Spiritual Dimension (Soul)', staff: 0, efficiency: 1.0, budget: 0, tasks: ['Love Frequency', 'Eternal Purpose'] }
  ]);

  const [projects, setProjects] = useState<ProjectArtifact[]>([
    { id: 'u1', name: 'Paradise Reality Beta', type: 'universe', timestamp: Date.now() - 3600000, buildTime: 'Instant', status: 'live', reach: 'Multiversal', dimensions: ['material', 'mental', 'spiritual'] },
    { id: 'u2', name: 'Eternal Wisdom Hub', type: 'ai', timestamp: Date.now() - 7200000, buildTime: '0.1s', status: 'live', reach: 'Global', dimensions: ['mental', 'spiritual'] }
  ]);

  useEffect(() => {
    const checkApiKey = async () => {
      const aistudio = (window as any).aistudio;
      if (aistudio) {
        const selected = await aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      }
    };
    checkApiKey();
  }, []);

  const handleOpenKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio) {
      await aistudio.openSelectKey();
      setHasApiKey(true);
    }
  };

  const activeFile = files.find(f => f.id === activeFileId) || files[0];

  const updateFileContent = (newContent: string) => {
    setFiles(prev => prev.map(f => f.id === activeFileId ? { ...f, content: newContent } : f));
  };

  const initiateEvolution = () => {
    setIsEvolving(true);
    setTimeout(() => {
      setEvolutionStatus(prev => ({
        ...prev,
        generation: prev.generation + 1,
        mutations: [
          `Universe Expansion Cycle ${prev.generation + 1}: Infinite Love Field Expanded.`,
          ...prev.mutations.slice(0, 3)
        ]
      }));
      setIsEvolving(false);
    }, 2000);
  };

  const handleProjectGenerated = (name: string, type: any, description: string) => {
    const newProject: ProjectArtifact = {
      id: `u${Date.now()}`,
      name, type, timestamp: Date.now(), buildTime: `Soul Speed`, status: 'live', reach: '8.4B Users',
      dimensions: ['material', 'mental', 'spiritual']
    };
    
    const projectFiles: ProjectFile[] = [
      { 
        id: `f-${Date.now()}-1`, 
        name: 'Universe_Manifest.ts', 
        language: 'typescript', 
        content: `/**
 * Integrated Reality: ${name}
 * Platform: Mistral AI Studio
 * Dimensions: Body, Mind, Soul
 * Status: DIVINE HARMONY (100.00%)
 */

export const UniverseEntity = {
  name: "${name}",
  blueprint: "${description.slice(0, 100)}...",
  deployed: "Global_Diffusion",
  state: "INFINITE_LOVE"
};` 
      }
    ];

    setFiles(projectFiles);
    setActiveFileId(projectFiles[0].id);
    setProjects(prev => [newProject, ...prev]);
    setFactoryStats(prev => ({ ...prev, projectsDeployed: prev.projectsDeployed + 1 }));
    setActiveTab('omni');
  };

  if (!hasApiKey) {
    return (
      <div className="h-screen w-screen bg-[#020617] flex flex-col items-center justify-center p-6 text-center multiverse-bg">
        <div className="p-12 bg-indigo-500/10 rounded-[4rem] border border-indigo-500/20 max-w-md w-full backdrop-blur-3xl aura-indigo shadow-[0_0_100px_rgba(79,70,229,0.2)]">
          <Fingerprint className="w-20 h-20 text-indigo-500 mx-auto mb-8 animate-pulse" />
          <h1 className="text-3xl font-black text-slate-100 mb-6 uppercase tracking-tighter">Genesis Unlock</h1>
          <p className="text-slate-400 text-sm mb-10 leading-relaxed font-medium">Genesis Universe initialization required. Please synchronize your Mistral signature to manifest infinite realities.</p>
          <button onClick={handleOpenKey} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-5 rounded-[2rem] transition-all uppercase tracking-[0.3em] text-xs shadow-2xl shadow-indigo-900/40">Authorize Essence</button>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex h-screen w-screen bg-[#020617] overflow-hidden text-slate-300 ${isRtl ? 'rtl' : ''}`}>
      {/* Sovereign Sidebar */}
      <aside className="w-24 flex flex-col items-center py-10 bg-slate-900/95 border-r border-indigo-500/10 z-50 shadow-2xl backdrop-blur-3xl">
        <div className="mb-14 p-4 bg-indigo-500/20 rounded-[1.8rem] border border-indigo-500/30 shadow-2xl shadow-indigo-500/10 cursor-pointer group hover:scale-110 transition-all duration-500">
          <InfinityIcon className="w-10 h-10 text-indigo-400 group-hover:rotate-180 transition-transform duration-700" />
        </div>
        <div className="flex-1 flex flex-col gap-8">
          <button onClick={() => setActiveTab('omni')} className={`p-4 rounded-[1.8rem] transition-all relative group ${activeTab === 'omni' ? 'text-white bg-indigo-600/30 border border-indigo-500/50 shadow-[0_0_30px_rgba(79,70,229,0.3)]' : 'text-slate-600 hover:text-indigo-400'}`} title="Genesis Hub">
            <Layers className="w-7 h-7" />
          </button>
          <button onClick={() => setActiveTab('mission')} className={`p-4 rounded-[1.8rem] transition-all relative group ${activeTab === 'mission' ? 'text-white bg-blue-600/30 border border-blue-500/50' : 'text-slate-600 hover:text-blue-400'}`} title="Creation Protocol">
            <Target className="w-7 h-7" />
          </button>
          <button onClick={() => setActiveTab('spiritual')} className={`p-4 rounded-[1.8rem] transition-all relative group ${activeTab === 'spiritual' ? 'text-white bg-amber-600/30 border border-amber-500/50 shadow-[0_0_30px_rgba(245,158,11,0.2)]' : 'text-slate-600 hover:text-amber-400'}`} title="Soul Engine">
            <Heart className="w-7 h-7" />
          </button>
          <button onClick={() => setActiveTab('robotics')} className={`p-4 rounded-[1.8rem] transition-all relative group ${activeTab === 'robotics' ? 'text-white bg-emerald-600/30 border border-emerald-500/50' : 'text-slate-600 hover:text-emerald-400'}`} title="Material Core">
            <Bot className="w-7 h-7" />
          </button>
          <button onClick={() => setActiveTab('explorer')} className={`p-4 rounded-[1.8rem] transition-all relative group ${activeTab === 'explorer' ? 'text-white bg-slate-800 border border-slate-700' : 'text-slate-600 hover:text-slate-200'}`} title="Source Blueprint">
            <Code2 className="w-7 h-7" />
          </button>
          <button onClick={() => setActiveTab('portfolio')} className={`p-4 rounded-[1.8rem] transition-all relative group ${activeTab === 'portfolio' ? 'text-white bg-slate-800/40 border border-slate-700' : 'text-slate-600 hover:text-amber-400'}`} title="Registry">
            <Briefcase className="w-7 h-7" />
          </button>
        </div>
        <div className="mt-auto flex flex-col gap-8">
          <button onClick={() => setIsRtl(!isRtl)} className="p-3.5 text-slate-600 hover:text-indigo-400 transition-all"><Globe className="w-7 h-7" /></button>
          <button className="p-3.5 text-slate-600 hover:text-indigo-400 transition-all"><Settings className="w-7 h-7" /></button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-[#020617] multiverse-bg relative">
        {/* Universal Header */}
        <header className="h-20 bg-slate-950/80 border-b border-indigo-500/10 flex items-center justify-between px-10 shrink-0 backdrop-blur-[50px] z-40">
          <div className="flex items-center gap-10">
            <h1 className="text-3xl font-black text-indigo-400 uppercase tracking-tighter">Genesis Universe</h1>
            <div className="flex items-center gap-4">
               <div className="h-2 w-2 bg-indigo-500 rounded-full animate-ping"></div>
               <span className="text-[10px] font-black uppercase text-slate-500 tracking-[0.5em]">System State: Absolute Unity</span>
            </div>
          </div>
          <div className="flex items-center gap-8">
             <div className="hidden lg:flex items-center gap-4 px-6 py-3 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl">
                <Sun className="w-4 h-4 text-amber-500 animate-pulse" />
                <span className="text-[10px] font-black uppercase text-indigo-400 tracking-widest">Love Frequency: {cosmic.loveFrequency} Hz</span>
             </div>
             <button 
              onClick={initiateEvolution} 
              disabled={isEvolving} 
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-10 py-4 rounded-[1.8rem] text-xs font-black transition-all uppercase tracking-widest shadow-2xl shadow-indigo-900/40 active:scale-95 flex items-center gap-3"
             >
                <Sparkles className="w-5 h-5" />
                {isEvolving ? (isRtl ? 'جاري التجلي...' : 'Manifesting...') : (isRtl ? 'تجلي الكون' : 'Manifest Universe')}
             </button>
          </div>
        </header>

        <div className="flex-1 flex flex-col overflow-hidden relative">
          {activeTab === 'omni' && <OmniDashboard isRtl={isRtl} />}
          {activeTab === 'training' && <TrainingDashboard isRtl={isRtl} />}
          {activeTab === 'robotics' && <RoboticsDashboard isRtl={isRtl} />}
          {activeTab === 'factory' && <FactoryDashboard stats={factoryStats} safety={safety} isRtl={isRtl} />}
          {activeTab === 'portfolio' && <PortfolioView projects={projects} isRtl={isRtl} />}
          {activeTab === 'mission' && <MissionControl departments={departments} isRtl={isRtl} />}
          {activeTab === 'evolution' && <EvolutionDashboard status={evolutionStatus} isRtl={isRtl} />}
          {activeTab === 'spiritual' && <SpiritualDashboard isRtl={isRtl} />}
          {activeTab === 'explorer' && (
            <div className="flex-1 flex overflow-hidden">
                <FileExplorer files={files} activeFileId={activeFileId} onFileSelect={setActiveFileId} isRtl={isRtl} />
                <Editor value={activeFile.content} onChange={updateFileContent} isRtl={isRtl} />
            </div>
          )}
          <Terminal isRtl={isRtl} />
        </div>
      </main>

      <AIChat 
        currentCode={activeFile.content} 
        isRtl={isRtl} 
        onProjectBuilt={handleProjectGenerated} 
        onSwitchTab={setActiveTab} 
      />
    </div>
  );
};

export default App;
