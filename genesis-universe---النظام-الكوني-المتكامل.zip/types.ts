
export type ModelMode = 'fast' | 'standard' | 'thinking';
export type SpeedMode = 'instant' | 'hyper' | 'warp' | 'universe' | 'soul';
export type ViewMode = 'omni' | 'explorer' | 'training' | 'robotics' | 'factory' | 'portfolio' | 'mission' | 'evolution' | 'spiritual';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  mode?: ModelMode;
  attachments?: {
    type: 'image' | 'video' | 'blueprint' | 'project';
    url: string;
    mimeType: string;
  }[];
}

export interface TrainingMetric {
  epoch: number;
  loss: number;
  accuracy: number;
  status: 'learning' | 'optimized' | 'sentient' | 'divine';
}

export interface CosmicMetrics {
  universalSatisfaction: number;
  realityStability: number;
  ethicalCompliance: number;
  loveFrequency: number;
  quantumTimeCompression: string;
  multiverseSimulations: number;
  creationVelocity: string;
  globalNodes: number;
  sovereignRobots: number;
}

export interface EvolutionCycle {
  generation: number;
  fitness: number;
  mutations: string[];
  status: 'optimizing' | 'stable' | 'evolving' | 'transcending';
}

export interface FactoryStats {
  projectsDeployed: number;
  avgBuildTime: string;
  activeDeployments: number;
  successRate: number;
  coresActive: number;
}

export interface SafetyStatus {
  ethicalAlignment: number;
  forbiddenPatternsBlocked: number;
  containmentLevel: 'secure' | 'critical' | 'isolated' | 'harmonized';
}

export interface DepartmentStatus {
  name: string;
  staff: number;
  efficiency: number;
  budget: number;
  tasks: string[];
}

export interface ProjectArtifact {
  id: string;
  name: string;
  type: 'web' | 'mobile' | 'ai' | 'robotics' | 'omni' | 'universe';
  timestamp: number;
  buildTime: string;
  status: 'live' | 'fabricating' | 'archived';
  reach: string;
  dimensions: ('material' | 'mental' | 'spiritual')[];
}

export interface ProjectFile {
  id: string;
  name: string;
  content: string;
  language: string;
  isOpen?: boolean;
}

export interface DatabaseTable {
  name: string;
  columns: { name: string; type: string; constraints?: string }[];
}
